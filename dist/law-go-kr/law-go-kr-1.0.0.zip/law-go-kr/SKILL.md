---
name: law-go-kr
description: 법제처 국가법령정보 OPEN API(DRF)로 법령·행정규칙을 검색하고, 별표·서식(HWP/HWPX/PDF 첨부파일)을 번호로 지정해 내려받아 파싱한다. 조문 본문을 조/항/호/목으로 구조화하고 food-code-analyzer 지식베이스로 내보낼 수 있다. 「식품의 기준 및 규격」처럼 본문이 비어있고 실제 내용이 첨부파일에 들어있는 고시를 다룰 때 사용. korean-doc-parser 스킬과 함께 동작한다.
---

# law-go-kr — 법제처 법령·별표 수집·파싱

법제처(www.law.go.kr) 국가법령정보 공동활용 OPEN API 를 호출해:

1. 법령/행정규칙(고시)을 이름으로 **검색**하고,
2. **별표 번호를 지정해**(예: `--byl "별표 4"`) 해당 첨부파일만 골라내고,
3. 파일을 **다운로드**한 뒤 `korean-doc-parser` 로 **파싱**하고,
4. 조문 본문을 **조/항/호/목 트리로 구조화**해 text/JSON/Markdown 으로 출력하거나
5. `food-code-analyzer` **지식베이스로 내보낸다**.

## 왜 필요한가

「식품의 기준 및 규격」(식약처 고시) 같은 문서는 law.go.kr 본문 페이지가
> 『식품의 기준 및 규격』의 자세한 내용은 상단 메뉴 "첨부파일" 버튼을 이용하십시오.

로만 되어 있고 실제 규격·정의는 전부 별표 첨부파일(HWP/PDF)에 있다.
따라서 본문 크롤링이 아니라 **첨부파일 다운로드 + 파싱**이 필요하다.

## 구조

```
law-go-kr/
├── SKILL.md
├── scripts/
│   ├── lawapi.py     HTTP 계층 — 재시도·타임아웃·디스크 캐시·오류 구분
│   ├── parsers.py    파싱 계층 — 별표 참조·조문 트리·출력 포맷 (순수 함수)
│   ├── law_fetch.py  CLI 와 오케스트레이션
│   └── run_local.sh  원클릭 실행
└── tests/            네트워크 없이 도는 단위·통합 테스트 (75개)
```

## 사전 요건

1. **OC 인증키**: open.law.go.kr 에서 OPEN API 를 신청하면 받는 아이디.
   환경변수로 설정하고 코드/리포에는 남기지 않는다.
   ```bash
   export LAW_GO_KR_OC=your_oc_id     # 또는 --oc 옵션
   ```
2. **네트워크**: 실행 환경이 `www.law.go.kr` 로 아웃바운드 HTTPS 가능해야 한다.
   Claude Code on the web 의 기본 egress 정책은 이 호스트를 차단하므로,
   Environments → Custom network 에 `www.law.go.kr`, `open.law.go.kr` 을 허용하거나
   접근 가능한 로컬/서버에서 실행한다. 차단 시 스크립트가 원인과 해결법을 안내한다.
3. **호출 IP 등록**: 네트워크가 열려도 법제처는 **OC 신청 시 등록한 서버 IP/도메인에서
   오는 호출만** 받는다. 미등록 IP 에서 호출하면 HTTP 200 과 함께 아래를 돌려준다.

   ```json
   {"result": "사용자 정보 검증에 실패하였습니다.",
    "msg": "OPEN API 호출 시 사용자 검증을 위하여 정확한 서버장비의 IP주소 및 도메인주소를 등록해 주세요."}
   ```

   ⚠️ **이 메시지는 'OC 키가 틀린 경우'에도 똑같이 나온다** — 실제로 존재하지 않는 키로
   호출해도 응답이 완전히 동일하다. 따라서 메시지만으로 원인을 구분할 수 없으니
   키와 IP 등록을 모두 확인해야 한다.

   클라우드/원격 실행 환경은 아웃바운드 IP 가 유동이라 등록을 맞추기 어렵다.
   **고정 IP 서버나 로컬 PC 에서 실행하는 것을 권한다.**
4. **의존성**: `requests` + korean-doc-parser 스킬의 파싱 스택
   (`hwp-hwpx-parser`, `pymupdf`, `python-docx`, `mammoth`, `paddleocr`, `pytesseract`).

## 사용법

```bash
S=.claude/skills/law-go-kr/scripts/law_fetch.py

# 0) 설정 점검 — 새 PC 에서 제일 먼저 실행할 것
python3 $S doctor
#  ✅ Python             3.11.15
#  ✅ requests           2.33.1
#  ✅ OC 인증키            kh***
#  ✅ law.go.kr 접속       HTTP 200
#  ✅ API 인증             검색 결과 1건
#  ✅ korean-doc-parser  .../parse_doc.py
#  ✅   hwp_hwpx_parser  .hwp/.hwpx
#  ...

# 1) 검색 → 행정규칙일련번호 확인
python3 $S search "식품등의 표시기준"

# 2) 별표·서식 목록 (번호 인식 결과 포함)
python3 $S annexes --query "식품등의 표시기준"
#  별표 4    [HWP/기타]  영양성분 표시대상 식품    https://...
#  별표 4    [PDF]       영양성분 표시대상 식품    https://...
#  별표 4의2 [HWP/기타]  추가 기준                https://...

# 3) '별표 4' 만 내려받아 파싱
python3 $S fetch --query "식품등의 표시기준" --byl "별표 4" --parse

# 4) 조문 본문을 구조화해 마크다운으로
python3 $S articles --query "식품위생법" --target law --article 1-5 --format markdown

# 5) 지식베이스로 내보내기 (먼저 --dry-run 으로 확인)
python3 $S export --query "식품의 기준 및 규격" --codex food --dry-run
python3 $S export --query "식품의 기준 및 규격" --codex food

# 6) 캐시 확인/삭제
python3 $S cache info
python3 $S cache clear
```

### 원클릭(로컬 실행)
```bash
export LAW_GO_KR_OC=your_oc_id
bash .claude/skills/law-go-kr/scripts/run_local.sh "식품등의 표시기준" "" "별표 4"
```

## 설정 점검 (`doctor`)

막히는 지점이 여럿이라(egress 차단 · OC 미설정 · IP 미등록 · 파서 누락) 한 번에
어디가 문제인지 짚어준다. 실패한 항목이 있으면 종료코드 1.

`설치됨, 의존성 'cobble' 누락` 처럼 **'미설치'와 '전이 의존성 누락'을 구분**하고,
pip 패키지명이 import 명과 다르면(`PIL` → `pillow`) 올바른 명령을 안내한다.

## 별표 지정 문법 (`--byl`)

| 입력 | 뜻 |
|---|---|
| `별표 4` / `별표4` / `별표 제4호` | 별표 4 (가지번호 없는 것만) |
| `별표 4의2` | 별표 4의2 만 |
| `4` | 종류 무관, 번호 4 (별표·별지·서식 모두) |
| `별지 1` | 별지 1 |
| `별표 4,별표 5` | 여러 개 |

가지번호는 **정확히** 비교한다 — `별표 4` 를 요청하면 `별표 4의2` 는 따라오지 않는다.
못 찾으면 인식된 별표 목록을 보여주므로 오타를 바로 알 수 있다.

## 조문 지정 문법 (`--article`)

`3` (제3조) · `3의2` (제3조의2) · `1-5` (범위) · `1,3,5` (여러 개)

## 공통 옵션

| 옵션 | 설명 |
|---|---|
| `--format text\|json\|markdown` | 출력 형식 |
| `--target law\|admrul\|ordin` | 법령 / 행정규칙(고시) / 자치법규 |
| `--via detail\|admbyl` | 본문에서 별표 링크 추출 / 별표 목록 직접 조회 |
| `--byl-search 1\|2\|3` | admbyl 검색범위 (기본 2=해당법령검색) |
| `--no-owner-filter` | 다른 고시 소속 별표도 함께 보기 |
| `--refresh` | 캐시 무시하고 새로 받기 |
| `--no-cache` | 캐시를 읽지도 쓰지도 않음 |
| `--ttl 86400` | 캐시 유효기간(초) |
| `--retries 4` | 실패 시 재시도 횟수(지수 백오프) |
| `--connect-timeout` / `--read-timeout` | 타임아웃 분리 |
| `-q, --quiet` | 진행 로그 숨김 |

## API 스펙 요점 (공식 가이드 확인분)

출처: [open.law.go.kr OPEN API 가이드](https://open.law.go.kr/LSO/openApi/guideList.do)

### `lawService.do` 의 `ID` 는 target 마다 의미가 다르다

| target | `ID` | 다른 파라미터 |
|---|---|---|
| `admrul` | **행정규칙일련번호** (13자리) | `LID` = 행정규칙ID, `LM` = 행정규칙명 |
| `eflaw` / `law` | **법령ID** | `MST` = 법령마스터번호, `JO` = 조번호 |

검색 응답에는 두 번호가 모두 들어 있다. 행정규칙ID(예: 36814)를 `ID` 에 넘기면
본문이 비어 오고 별표를 못 찾는다 — 실제로 겪은 오류다.

### `admbyl` 의 `search` = 검색범위

| 값 | 의미 |
|---|---|
| 1 | 별표서식명 (기본) |
| **2** | **해당법령검색** ← 이 스킬의 기본값 |
| 3 | 별표본문검색 |

기본값 1 은 별표 *이름* 으로 찾기 때문에 이름이 비슷한 **다른 고시의 별표**가
딸려온다. 이 스킬은 `search=2` 를 기본으로 쓰고, 그래도 섞이면 `관련행정규칙명`
으로 한 번 더 걸러낸다(`--no-owner-filter` 로 해제).

### 6자리 번호 인코딩

`별표번호`(admbyl) / `별표키`(admrul 상세) 와 `JO`(조번호)는 같은 규칙을 쓴다
— **끝 2자리가 가지번호**다.

```
000100 → 별표 1        000400 → 별표 4        000402 → 별표 4의2
000200 → 제2조         001002 → 제10조의2
```

### ⚠️ 같은 필드명 `별표번호` 가 target 마다 다른 값을 준다 (실제 응답으로 확인)

| 응답 | `별표번호` 의 뜻 | 진짜 번호 |
|---|---|---|
| `admbyl` 검색 | 진짜 번호(0 패딩) | `별표번호` 그대로 디코딩 |
| `admrul` 상세 (`lawService.do`) | **별표/별지/별도 각 그룹 안의 순번일 뿐** | `별표키` 필드 |

`admrul` 상세 응답은 별표 1~6은 `별표번호` "0001"~"0006"(그룹 순번), 별지는
다시 "0001"부터, 별도도 다시 "0001"부터 시작한다 — 종류가 다른데 번호가
겹친다. 진짜 번호는 `별표키`(예: "000400" → 별표 4)에 있다. 이 스킬은
`별표키` 를 우선 쓰고 없을 때만 `별표번호` 로 폴백한다.

종류 필드명도 다르다: `admbyl` 은 `별표종류`, `admrul` 상세는 `별표구분`
(값은 "별표"/"별지"/"별도" 로 동일).

### 문서 제목 필드도 부서명이 앞에 온다

`admrul` 상세는 `담당부서기관명`("식품의약품안전처(식품표시광고정책과)")이
`행정규칙명` 보다 먼저 나온다. '명'으로 끝나는 첫 필드를 쓰면 부서명을 제목으로
잘못 보고한다 — `detail_title()` 은 `행정규칙명`/`법령명` 을 우선 찾고, 없을
때만 부처·부서·기관·담당·종류가 안 들어간 '명' 필드로 폴백한다.

## 동작 원리

- 검색: `GET /DRF/lawSearch.do?OC=..&target=admrul&type=JSON&query=..`
- 상세: `GET /DRF/lawService.do?OC=..&target=admrul&type=JSON&ID=<seq>`
- 별표 링크 추출: 응답 JSON 을 재귀 탐색해 키에 `링크/파일/다운로드`가 있고 값이
  URL/경로인 항목을 수집(필드명이 버전마다 달라도 견고). 별표 번호는 `별표번호`·
  `별표가지번호`·`별표종류` 필드를 우선 쓰고, 없으면 제목에서 파싱한다.
- 본문에서 별표를 못 찾으면 `target=admbyl` 직접 조회로 자동 폴백한다.
- 다운로드: Content-Disposition 파일명 우선, 없으면 매직바이트로 확장자 판별
  (PDF `%PDF`, HWP/DOC OLE2 `D0CF11E0`, HWPX/DOCX ZIP → 내부 구조로 구분).
  한 번의 실행 안에서 이름이 겹치면 `(2)` 를 붙여 덮어쓰지 않는다.
- 캐시: URL+파라미터(OC 제외) 해시로 `~/.cache/law-go-kr/` 에 저장, 기본 TTL 24시간.
- 파싱: `korean-doc-parser/scripts/parse_doc.py` 로 위임.

## 테스트

네트워크 없이 전부 돈다 — egress 가 막힌 환경에서도 로직 검증이 가능하다.

```bash
cd .claude/skills/law-go-kr && python3 -m unittest discover -s tests -t tests
# Ran 75 tests — OK
```

## 한계

- DRM/암호 걸린 첨부는 다운로드는 되어도 파싱 불가(FOSS 공통 한계).
- 별표가 스캔 이미지 PDF 면 parse_doc.py 가 자동으로 OCR(PaddleOCR)로 폴백한다.
- 조문 구조화는 법제처가 주는 형태에 따라 결과가 달라진다. `조문단위` 배열이 있으면
  그대로 쓰고, 텍스트 blob 이면 정규식으로 파싱하므로 완벽하지 않을 수 있다.
- **법정 정의처럼 정확도가 중요한 텍스트는 파싱 결과를 원본과 대조 확인할 것.**
