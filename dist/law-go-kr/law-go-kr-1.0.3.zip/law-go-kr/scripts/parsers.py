#!/usr/bin/env python3
"""법제처 응답 파싱 계층 — 네트워크에 의존하지 않는 순수 함수 모음.

세 가지를 담당한다:
  1) 별표 참조 파싱·매칭   — "별표 4", "별표4의2", "별지 1", "4" 를 정규화해 선별
  2) 조문 본문 구조화      — 조 / 항 / 호 / 목 계층 트리로 분해
  3) 출력 포맷            — text / json / markdown, food-code-analyzer 내보내기

네트워크를 타지 않으므로 단위 테스트로 전부 검증할 수 있다(tests/ 참고).
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass, asdict

# ---------------------------------------------------------------------------
# 1. 별표 참조 (별표 / 별지 / 서식 / 별도)
# ---------------------------------------------------------------------------

BYL_KINDS = ("별표", "별지", "서식", "별도")

# "[별표 4]", "별표4의2", "별표 제4호", "별지 제1호서식" 등을 모두 잡는다.
_BYL_REF_RE = re.compile(
    r"(별표|별지|서식|별도)\s*(?:제\s*)?(\d+)\s*(?:의\s*(\d+))?"
)
# 종류 없이 번호만 준 스펙: "4", "4의2"
_BARE_NUM_RE = re.compile(r"^\s*(\d+)\s*(?:의\s*(\d+))?\s*$")


@dataclass(frozen=True)
class BylRef:
    """별표 참조. kind/number 가 None 이면 '지정 안 함'(와일드카드)을 뜻한다."""

    kind: str | None = None
    number: int | None = None
    branch: int | None = None  # 가지번호: "별표 4의2" → 2

    def label(self) -> str:
        if self.number is None:
            return self.kind or "?"
        base = f"{self.kind or '별표'} {self.number}"
        return f"{base}의{self.branch}" if self.branch else base

    def to_dict(self) -> dict:
        return asdict(self)


def parse_byl_ref(text: str) -> BylRef | None:
    """제목 문자열에서 첫 번째 별표 참조를 뽑는다. 없으면 None."""
    if not text:
        return None
    m = _BYL_REF_RE.search(text)
    if not m:
        return None
    kind, num, branch = m.group(1), m.group(2), m.group(3)
    return BylRef(kind, int(num), int(branch) if branch else None)


def parse_byl_spec(spec: str) -> BylRef:
    """사용자가 --byl 로 준 값을 파싱한다.

    "별표 4" / "별표4" / "별표 제4호" / "4" / "4의2" / "별지 1" 을 모두 허용.
    종류를 안 적으면 kind=None(모든 종류 매칭).
    """
    spec = (spec or "").strip()
    if not spec:
        raise ValueError("별표 지정이 비어 있습니다")

    bare = _BARE_NUM_RE.match(spec)
    if bare:
        return BylRef(None, int(bare.group(1)), int(bare.group(2)) if bare.group(2) else None)

    ref = parse_byl_ref(spec)
    if ref is None:
        # 종류만 준 경우: "별표"
        for k in BYL_KINDS:
            if spec.replace(" ", "") == k:
                return BylRef(k, None, None)
        raise ValueError(f"별표 지정을 이해할 수 없습니다: {spec!r} (예: '별표 4', '4', '별지 1')")
    return ref


def parse_byl_specs(spec: str) -> list[BylRef]:
    """쉼표로 구분된 여러 지정을 파싱: '별표 4, 별표 5' → [BylRef, BylRef]"""
    return [parse_byl_spec(part) for part in spec.split(",") if part.strip()]


def byl_matches(spec: BylRef, ref: BylRef | None) -> bool:
    """스펙이 참조와 일치하는지. 스펙에서 None 인 필드는 아무거나 허용한다.

    가지번호는 정확히 비교한다 — '별표 4' 를 요청하면 '별표 4의2' 는 매칭하지 않는다.
    (엉뚱한 별표를 조용히 가져오는 것보다 못 찾았다고 알려주는 편이 낫다.)
    """
    if ref is None:
        return False
    if spec.kind is not None and spec.kind != ref.kind:
        return False
    if spec.number is not None and spec.number != ref.number:
        return False
    return spec.branch == ref.branch


def decode_byl_number(raw, branch_raw=None) -> tuple[int, int | None] | None:
    """법제처 `별표번호` 필드를 (번호, 가지번호) 로 푼다.

    실제 응답은 0 으로 채운 문자열이고 **끝 두 자리가 가지번호**다:

        "000100" → 별표 1        "000400" → 별표 4
        "000402" → 별표 4의2     "010000" → 별표 100

    이걸 그대로 int 로 읽으면 별표 1 이 '별표 100' 이 되어, 번호로 찾는 기능이
    통째로 어긋난다(실제로 겪은 버그).

    자리수가 3 미만이면 패딩되지 않은 그대로의 번호로 본다.
    별도의 가지번호 필드가 있으면 그쪽을 우선한다.
    """
    digits = re.sub(r"\D", "", str(raw if raw is not None else ""))
    if not digits:
        return None
    value = int(digits)

    if len(digits) >= 3:
        num, branch = divmod(value, 100)
    else:
        num, branch = value, 0

    if branch_raw not in (None, "", []):
        bd = re.sub(r"\D", "", str(branch_raw))
        if bd:
            branch = int(bd)

    return (num, branch or None) if num else None


def _pick_title(item: dict) -> str | None:
    """항목에서 '별표 제목' 을 고른다.

    단순히 '명' 으로 끝나는 첫 키를 쓰면 `소관부처명`("식품의약품안전처") 같은
    엉뚱한 값을 집는다 — 실제 응답에서 그 필드가 `별표명` 보다 앞에 온다.
    """
    for needle in ("별표명", "별표서식명", "서식명", "제목"):
        for k, v in item.items():
            if needle in k and isinstance(v, str) and v.strip():
                return v.strip()
    for k, v in item.items():
        if (
            isinstance(v, str)
            and v.strip()
            and k.endswith("명")
            and not any(x in k for x in ("부처", "규칙", "법령", "기관", "종류"))
        ):
            return v.strip()
    return None


def byl_ref_from_item(item: dict) -> BylRef | None:
    """admbyl/admrul 응답 항목에서 별표 참조를 만든다.

    같은 이름 `별표번호` 가 target 마다 다른 뜻이다 (실제 응답으로 확인):
      admbyl 검색 응답 : 별표번호="000100" → 진짜 번호 (0 패딩, /100 로 디코딩)
      admrul 상세 응답 : 별표번호="0001"   → **그룹 내 순번일 뿐, 가짜.**
                        진짜 번호는 별도 필드 `별표키`="000100" 에 있다.

    `별표번호` 만 믿으면 admrul 상세에서 같은 고시의 별표들이 전부 1~7 그룹
    순번으로 뒤섞여 나온다(실제로 겪은 버그 — 모든 항목이 "번호 미상"이었던
    원인도 이것과 얽혀 있었다). `별표키` 가 있으면 그쪽을 우선한다.

    종류 필드명도 다르다: admbyl 은 `별표종류`, admrul 상세는 `별표구분`
    (값은 "별표"/"별지"/"별도" 로 동일).
    """
    if not isinstance(item, dict):
        return None

    def pick(*needles):
        for k, v in item.items():
            if any(n in k for n in needles) and v not in (None, "", []):
                return v
        return None

    raw_num = pick("별표키") or pick("별표번호")
    if raw_num is not None:
        decoded = decode_byl_number(raw_num, pick("가지번호"))
        if decoded:
            kind_raw = str(pick("별표종류", "별표구분") or "별표")
            kind = next((k for k in BYL_KINDS if k in kind_raw), "별표")
            return BylRef(kind, decoded[0], decoded[1])

    title = _pick_title(item)
    return parse_byl_ref(title) if title else None


# ---------------------------------------------------------------------------
# 2. 조문 구조화 (조 / 항 / 호 / 목)
# ---------------------------------------------------------------------------

# ①~⑳(1-20) 뿐 아니라 ㉑~㉟(21-35, U+3251~325F), ㊱~㊿(36-50, U+32B1~32BF)
# 까지 커버한다. 20개까지만 인식하면 21번째 이후 항이 전부 조문 본문에
#뭉개진다(실제로 21개짜리 항목으로 구성된 조문에서 재현된 문제).
CIRCLED = (
    "①②③④⑤⑥⑦⑧⑨⑩⑪⑫⑬⑭⑮⑯⑰⑱⑲⑳"
    + "".join(chr(c) for c in range(0x3251, 0x3260))  # ㉑-㉟
    + "".join(chr(c) for c in range(0x32B1, 0x32C0))  # ㊱-㊿
)
_CIRCLED_VALUE = {ch: i + 1 for i, ch in enumerate(CIRCLED)}
_MOK_LETTERS = "가나다라마바사아자차카타파하"

_ART_RE = re.compile(r"^\s*제\s*(\d+)\s*조\s*(?:의\s*(\d+))?\s*(?:\(([^)]*)\))?\s*(.*)$")
_PARA_CIRCLED_RE = re.compile(rf"^\s*([{CIRCLED}])\s*(.*)$")
_PARA_PAREN_RE = re.compile(r"^\s*\((\d{1,2})\)\s*(.*)$")
# "1의2." 처럼 가지번호가 붙은 호도 인식한다 — 마침표 직전 숫자만 보던
# 예전 패턴은 "1의2." 를 통째로 못 알아보고 앞 호의 내용에 붙여버렸다.
_HO_RE = re.compile(r"^\s*(\d{1,2}(?:의\d{1,2})?)\s*\.\s*(.*)$")
_MOK_RE = re.compile(rf"^\s*([{_MOK_LETTERS}])\s*\.\s*(.*)$")
_CIRCLED_INLINE_RE = re.compile(rf"(?<!^)(?=[{CIRCLED}])")

_TAG_RE = re.compile(r"<[^>]+>")
_CDATA_RE = re.compile(r"<!\[CDATA\[(.*?)\]\]>", re.S)


def strip_markup(text: str) -> str:
    """법제처 응답에 섞여 오는 CDATA/HTML 태그/엔티티를 걷어낸다."""
    if not text:
        return ""
    text = _CDATA_RE.sub(r"\1", text)
    text = _TAG_RE.sub("", text)
    for ent, ch in (("&lt;", "<"), ("&gt;", ">"), ("&amp;", "&"), ("&quot;", '"'), ("&nbsp;", " ")):
        text = text.replace(ent, ch)
    return text


def break_before_circled(text: str) -> str:
    """원문자(①②③...) 앞에 줄바꿈이 없으면 넣는다.

    일부 응답(예: 자치법규 target=ordin)은 조문 하나의 전체 텍스트가
    줄바꿈 없이 한 줄로 온다 — "...할 수 있다.② 제1항에 따른..." 처럼
    항이 이어 붙어 있어서, 줄 단위로 동작하는 parse_articles 가 항을
    하나도 못 알아본다(실제로 5개 항이 있는 조문이 0개 항으로 나온 사례).

    원문자는 한국 법령 표기에서 거의 예외 없이 항의 시작에만 쓰이므로
    ("가.", "1." 과 달리 날짜·목록 등 다른 문맥과 헷갈릴 여지가 없다),
    이 문자 앞에서 줄을 나누는 것은 안전하다. 이미 줄 앞에 있는 경우는
    빈 줄만 하나 늘어나고 parse_articles 가 빈 줄을 건너뛰므로 무해하다.
    """
    return _CIRCLED_INLINE_RE.sub("\n", text)


def parse_articles(text: str) -> list[dict]:
    """조문 텍스트를 조/항/호/목 트리로 분해한다.

    반환: [{"번호": "1", "가지": None, "제목": "목적", "내용": "...",
            "항": [{"번호": 1, "내용": "...", "호": [{"번호": "1", "내용": "...",
                    "목": [{"번호": "가", "내용": "..."}]}]}]}]

    조 헤더가 하나도 없으면 빈 리스트를 반환한다(호출부에서 원문 폴백 판단).
    """
    text = strip_markup(text)
    articles: list[dict] = []
    cur_art = cur_para = cur_ho = None

    def new_article(num, branch, title, rest):
        nonlocal cur_art, cur_para, cur_ho
        cur_art = {
            "번호": num,
            "가지": branch,
            "제목": title,
            "내용": rest.strip(),
            "항": [],
        }
        cur_para = cur_ho = None
        articles.append(cur_art)

    for raw in text.splitlines():
        line = raw.strip()
        if not line:
            continue

        m = _ART_RE.match(line)
        if m and m.group(1):
            new_article(m.group(1), m.group(2), (m.group(3) or "").strip() or None, m.group(4))
            continue

        if cur_art is None:
            # 조 헤더 이전의 머리말은 버리지 않고 임시 조에 담는다.
            new_article(None, None, None, "")
            cur_art["내용"] = line
            continue

        m = _PARA_CIRCLED_RE.match(line)
        if m:
            cur_para = {"번호": _CIRCLED_VALUE[m.group(1)], "내용": m.group(2).strip(), "호": []}
            cur_ho = None
            cur_art["항"].append(cur_para)
            continue

        m = _PARA_PAREN_RE.match(line)
        if m:
            cur_para = {"번호": int(m.group(1)), "내용": m.group(2).strip(), "호": []}
            cur_ho = None
            cur_art["항"].append(cur_para)
            continue

        m = _HO_RE.match(line)
        if m:
            if cur_para is None:
                cur_para = {"번호": None, "내용": "", "호": []}
                cur_art["항"].append(cur_para)
            cur_ho = {"번호": m.group(1), "내용": m.group(2).strip(), "목": []}
            cur_para["호"].append(cur_ho)
            continue

        m = _MOK_RE.match(line)
        if m and cur_ho is not None:
            cur_ho["목"].append({"번호": m.group(1), "내용": m.group(2).strip()})
            continue

        # 분류 안 되는 줄은 가장 가까운 노드의 내용에 이어 붙인다.
        target = cur_ho or cur_para or cur_art
        key = "내용"
        target[key] = (target.get(key, "") + " " + line).strip()

    # 조 번호가 하나도 없으면 구조화 실패로 본다.
    if all(a["번호"] is None for a in articles):
        return []
    return articles


def _iter_dicts(node):
    if isinstance(node, dict):
        yield node
        for v in node.values():
            yield from _iter_dicts(v)
    elif isinstance(node, list):
        for v in node:
            yield from _iter_dicts(v)


def _clean_num(raw: str | None) -> str | None:
    """호/목 번호에서 뒤의 마침표를 뗀다 ('1.' → '1', '5의2.' → '5의2').

    렌더러가 마침표를 따로 붙이므로 원본 그대로 두면 '1..' 처럼 겹친다.
    """
    return raw.rstrip(".") if raw else raw


def _strip_own_marker(content: str, marker: str | None) -> str:
    """내용 맨 앞에 이미 박혀 있는 번호를 제거한다.

    법령 API 구조화 응답은 항내용/호내용/목내용에 해당 번호를 이미 포함해서
    준다 ("① 누구든지...", '1. "식품"이란...'). 렌더러(articles_to_text 등)가
    번호를 따로 붙이므로 그대로 두면 "① ① 누구든지..." 처럼 중복된다.
    """
    if not marker:
        return content
    stripped = content.lstrip()
    return stripped[len(marker):].lstrip() if stripped.startswith(marker) else content


def _strip_article_head(content: str, num, branch, title) -> str:
    """조문내용 맨 앞의 '제N조(제목)' 머리말을 뗀다.

    정규식 파싱 경로(parse_articles)는 조/항 번호를 캡처하고 남은 본문만
    저장하는데, 구조화 JSON 경로는 조문내용에 머리말이 그대로 포함돼 온다
    ("제1조(목적) 이 법은 ..."). 두 경로의 출력을 맞추기 위해 동일하게 뗀다.
    """
    if not num:
        return content
    head = f"제{num}조" + (f"의{branch}" if branch else "")
    stripped = content.lstrip()
    if title and stripped.startswith(f"{head}({title})"):
        return stripped[len(f"{head}({title})") :].lstrip()
    if stripped.startswith(head):
        rest = stripped[len(head) :].lstrip()
        # '제2조 정의' 처럼 괄호 없이 제목이 그대로 이어지는 경우까지는
        # 건드리지 않는다 — 괄호쌍이 없으면 본문과 구분할 수 없다.
        if rest.startswith("("):
            close = rest.find(")")
            if close != -1:
                return rest[close + 1 :].lstrip()
    return content


def _parse_ho_list(ho_list) -> list[dict]:
    """'호' 리스트를 표준 {"번호","내용","목"} 형태로 변환한다."""
    hos = []
    for h in ho_list or []:
        if not isinstance(h, dict):
            continue
        hnum_raw = next(
            (strip_markup(str(x)) for kk, x in h.items() if "호번호" in kk and x), None
        )
        hbody_raw = next(
            (strip_markup(str(x)) for kk, x in h.items() if "호내용" in kk and isinstance(x, str)),
            "",
        )
        moks = []
        for kk, v in h.items():
            if "목" in kk and isinstance(v, list):
                for m in v:
                    if not isinstance(m, dict):
                        continue
                    mnum_raw = next(
                        (strip_markup(str(x)) for kkk, x in m.items() if "목번호" in kkk and x),
                        None,
                    )
                    mbody_raw = next(
                        (
                            strip_markup(str(x))
                            for kkk, x in m.items()
                            if "목내용" in kkk and isinstance(x, str)
                        ),
                        "",
                    )
                    moks.append(
                        {
                            "번호": _clean_num(mnum_raw),
                            "내용": _strip_own_marker(mbody_raw, mnum_raw).strip(),
                        }
                    )
        hos.append(
            {
                "번호": _clean_num(hnum_raw),
                "내용": _strip_own_marker(hbody_raw, hnum_raw).strip(),
                "목": moks,
            }
        )
    return hos


def _parse_para_list(para_val) -> list[dict]:
    """'항' 값(리스트 또는 단일 dict)을 표준 paragraph 리스트로 변환한다.

    항이 여러 개면 리스트로 오지만, 항 구분 없이 바로 호부터 시작하는
    조문(예: 정의 조항)은 '항' 자체가 {"호": [...]} 형태의 단일 dict로 온다.
    이 경우를 list 로만 처리하면 안의 호 항목이 통째로 사라진다
    (실제로 겪은 버그 — 「식품위생법」 제2조 정의의 호 9개가 전부 유실됐었다).
    """
    if isinstance(para_val, dict):
        ho_list = para_val.get("호")
        if isinstance(ho_list, list):
            return [{"번호": None, "내용": "", "호": _parse_ho_list(ho_list)}]
        para_val = [para_val]

    paras = []
    for p in para_val or []:
        if not isinstance(p, dict):
            continue
        pnum_raw = next(
            (str(x) for kk, x in p.items() if "번호" in kk and isinstance(x, str) and x), None
        )
        pbody_raw = next(
            (strip_markup(str(x)) for kk, x in p.items() if "내용" in kk and isinstance(x, str)),
            "",
        )
        ho_list = p.get("호") if isinstance(p.get("호"), list) else None
        paras.append(
            {
                "번호": pnum_raw,
                "내용": _strip_own_marker(pbody_raw, pnum_raw).strip(),
                "호": _parse_ho_list(ho_list) if ho_list else [],
            }
        )
    return paras


def extract_articles(detail: dict) -> list[dict]:
    """상세 JSON에서 조문 트리를 뽑는다.

    1순위: '조문단위' 배열(법령 target 의 구조화 응답)
    2순위: 조문 관련 텍스트 blob 을 모아 parse_articles 로 파싱
    """
    units: list[dict] = []
    for d in _iter_dicts(detail):
        for k, v in d.items():
            if "조문단위" in k and isinstance(v, list):
                units.extend(x for x in v if isinstance(x, dict))

    if units:
        out = []
        for u in units:
            # '전문' 등 조문이 아닌 장/절 표제 항목은 제외한다. 실제로 겪은
            # 버그: "제1장 총칙" 이 조문번호="1" 을 공유해 가짜 제1조로 잡혔다.
            status = next((v for kk, v in u.items() if "조문여부" in kk), None)
            if status not in (None, "", "조문"):
                continue

            def g(*needles, default=""):
                for k, v in u.items():
                    if any(n in k for n in needles) and isinstance(v, str):
                        return strip_markup(v).strip()
                return default

            num = g("조문번호", default=None) or None
            branch_raw = g("조문가지번호", default=None)
            # "0" 은 '가지 없음' 을 뜻하는 값이지 진짜 가지번호가 아니다.
            # 이걸 그대로 두면 truthy 라서 "제5조의0" 같은 존재하지 않는
            # 조문이 생긴다 — 별표번호(0패딩)·부서명 우선순위에서 이미
            # 겪은 것과 같은 종류의 "문자열이라 falsy 검사가 안 먹는" 버그.
            branch = branch_raw if branch_raw not in (None, "", "0") else None
            title = g("조문제목", default=None) or None

            paras: list[dict] = []
            for k, v in u.items():
                if k.startswith("항"):
                    paras = _parse_para_list(v)
                    break

            out.append(
                {
                    "번호": num,
                    "가지": branch,
                    "제목": title,
                    "내용": _strip_article_head(g("조문내용"), num, branch, title),
                    "항": paras,
                }
            )
        return out

    return _extract_from_text_blobs(detail)


# 조문 본문이 아닌 필드는 '내용' 이 들어가도 blob 수집에서 제외한다.
# 실제로 겪은 문제: '부칙내용' 필드(수십 년치 개정이력 텍스트)가 이
# 제외 목록 없이 조문 blob 과 함께 수집돼, 부칙 앞부분이 번호 없는
# 가짜 조문으로 둔갑했다(자치법규 target=ordin 에서 재현).
_BLOB_EXCLUDE = ("부칙", "제개정이유", "관련")


def _extract_from_text_blobs(detail: dict) -> list[dict]:
    """구조화된 조문단위가 없을 때, 텍스트 blob 을 모아 정규식으로 파싱한다.

    두 가지를 추가로 처리한다:
    1) 조문내용이 문자열이 아니라 '조별 문자열의 리스트' 로 오는 응답이
       있다(여러 부처의 admrul 상세에서 확인) — 그대로 두면
       isinstance(v, str) 검사에 걸려 통째로 무시되고 "본문이 비어
       있다" 는 잘못된 안내가 나간다. 리스트면 줄바꿈으로 합쳐 하나의
       blob 취급한다.
    2) 그래도 정규식이 "제N조" 구조를 하나도 못 찾았는데 원문 텍스트
       자체는 충분히 긴 경우(예: "Ⅰ.총칙 1.목적 가. ..." 같은 개요식
       고시 본문 — 「식품등의 표시기준」실제 사례), 빈 리스트를 돌려주면
       "본문이 비어 있다" 는 완전히 틀린 메시지가 나간다. 이럴 땐 구조를
       억지로 지어내지 않고, 번호 없는 원문 그대로를 조문 하나로 감싸
       돌려준다 — 있는 내용을 없다고 하지 않는 것이 우선이다.
    """
    # 1순위: 실제로 확인된 조문 본문 필드명과 정확히 일치하면 길이 제한 없이
    # 그대로 믿는다. 짧아도(예: "이 조례 시행에 필요한 사항은 규칙으로
    # 정한다" — 37자) 진짜 조문이면 온전히 살려야 한다 — 아래 2순위의
    # 길이 임계값(>40자)을 여기에도 적용하면 짧고 정상적인 조문이
    # 통째로 빠진다(실제로 겪은 문제, 자치법규 제11조).
    _EXACT_BODY_KEYS = ("조문내용", "조내용")
    blobs: list[str] = []
    for d in _iter_dicts(detail):
        for k, v in d.items():
            if k in _EXACT_BODY_KEYS and isinstance(v, str) and v.strip():
                blobs.append(v)
            elif (
                k in _EXACT_BODY_KEYS
                and isinstance(v, list)
                and v
                and all(isinstance(x, str) for x in v)
            ):
                blobs.append("\n".join(x for x in v if x))

    # 2순위: 정확히 일치하는 필드가 없으면(아직 못 본 target 형태 등),
    # '조문'/'내용' 이 들어간 필드를 넓게 훑되 — 넓게 훑는 만큼 길이
    # 임계값으로 짧은 메타데이터(코드·번호 리스트 등)를 걸러낸다.
    # 실제로 "조문번호":["000100","000100"] 같은 코드 리스트가 '조문'
    # 부분문자열에 걸려 유령 조문으로 샌 적이 있다.
    if not blobs:
        for d in _iter_dicts(detail):
            for k, v in d.items():
                if any(x in k for x in _BLOB_EXCLUDE):
                    continue
                if isinstance(v, str) and ("조문" in k or "내용" in k) and len(v) > 40:
                    blobs.append(v)
                elif (
                    isinstance(v, list)
                    and ("조문" in k or "내용" in k)
                    and v
                    and all(isinstance(x, str) for x in v)
                ):
                    joined_list = "\n".join(x for x in v if x)
                    if len(joined_list) > 40:
                        blobs.append(joined_list)

    if not blobs:
        return []

    joined = "\n".join(blobs)
    arts = parse_articles(break_before_circled(joined))
    if arts:
        return arts

    raw = strip_markup(joined).strip()
    if len(raw) > 40:
        return [{"번호": None, "가지": None, "제목": None, "내용": raw, "항": []}]
    return []


def filter_articles(articles: list[dict], spec: str | None) -> list[dict]:
    """--article '3' / '3의2' / '1-5' 로 조문을 선별한다."""
    if not spec:
        return articles
    wanted_exact: set[tuple[str, str | None]] = set()
    ranges: list[tuple[int, int]] = []
    for part in spec.split(","):
        part = part.strip()
        if not part:
            continue
        if "-" in part and "의" not in part:
            lo, _, hi = part.partition("-")
            try:
                ranges.append((int(lo), int(hi)))
                continue
            except ValueError:
                pass
        num, _, branch = part.partition("의")
        wanted_exact.add((num.strip(), branch.strip() or None))

    def keep(a):
        num, branch = a.get("번호"), a.get("가지")
        if (str(num), str(branch) if branch else None) in wanted_exact:
            return True
        try:
            n = int(num)
        except (TypeError, ValueError):
            return False
        return any(lo <= n <= hi for lo, hi in ranges)

    return [a for a in articles if keep(a)]


# ---------------------------------------------------------------------------
# 3. 출력 포맷
# ---------------------------------------------------------------------------


def para_label(pn) -> str:
    """항 번호를 원문자로 표기한다 — 호('1.')와 눈으로 구분되게.

    JSON 응답은 이미 '①' 로 주는 경우가 있어 그대로 통과시킨다.
    """
    if pn in (None, ""):
        return ""
    if isinstance(pn, str) and pn.strip() and pn.strip()[0] in CIRCLED:
        return pn.strip()[0]
    try:
        n = int(pn)
    except (TypeError, ValueError):
        return str(pn)
    return CIRCLED[n - 1] if 1 <= n <= len(CIRCLED) else f"({n})"


def articles_to_text(articles: list[dict]) -> str:
    lines = []
    for a in articles:
        head = f"제{a['번호']}조" if a.get("번호") else "(조 번호 미상)"
        if a.get("가지"):
            head += f"의{a['가지']}"
        if a.get("제목"):
            head += f"({a['제목']})"
        lines.append(head)
        if a.get("내용"):
            lines.append(f"  {a['내용']}")
        for p in a.get("항", []):
            label = para_label(p.get("번호"))
            prefix = f"  {label} " if label else "  "
            lines.append(f"{prefix}{p.get('내용', '')}".rstrip())
            for h in p.get("호", []):
                lines.append(f"    {h.get('번호')}. {h.get('내용', '')}".rstrip())
                for mk in h.get("목", []):
                    lines.append(f"      {mk.get('번호')}. {mk.get('내용', '')}".rstrip())
        lines.append("")
    return "\n".join(lines).rstrip() + "\n" if lines else ""


def articles_to_markdown(articles: list[dict], title: str | None = None) -> str:
    lines = [f"# {title}", ""] if title else []
    for a in articles:
        head = f"제{a['번호']}조" if a.get("번호") else "(조 번호 미상)"
        if a.get("가지"):
            head += f"의{a['가지']}"
        if a.get("제목"):
            head += f" ({a['제목']})"
        lines.append(f"## {head}")
        lines.append("")
        if a.get("내용"):
            lines.append(a["내용"])
            lines.append("")
        for p in a.get("항", []):
            label = para_label(p.get("번호"))
            lines.append(f"{label} {p.get('내용', '')}".strip() if label else p.get("내용", ""))
            for h in p.get("호", []):
                lines.append(f"    - **{h.get('번호')}.** {h.get('내용', '')}".rstrip())
                for mk in h.get("목", []):
                    lines.append(f"        - {mk.get('번호')}. {mk.get('내용', '')}".rstrip())
            lines.append("")
    return "\n".join(lines).rstrip() + "\n"


def render(payload, fmt: str, title: str | None = None) -> str:
    """조문 트리 또는 임의 데이터를 요청한 포맷으로 직렬화한다."""
    if fmt == "json":
        return json.dumps(payload, ensure_ascii=False, indent=2) + "\n"
    if isinstance(payload, list) and payload and isinstance(payload[0], dict) and "항" in payload[0]:
        return articles_to_markdown(payload, title) if fmt == "markdown" else articles_to_text(payload)
    if fmt == "markdown":
        return f"# {title}\n\n{payload}\n" if title else f"{payload}\n"
    return f"{payload}\n"


# ---------------------------------------------------------------------------
# 4. food-code-analyzer 내보내기
# ---------------------------------------------------------------------------

_DEF_RE = re.compile(r'^\s*(?:\d+[).]\s*)?"?([^"()]{2,40}?)"?\s*(?:이|란|라)\s*(?:함은|한다|은|는)?\s*(.+)$')


def articles_to_kb_entries(articles: list[dict], category: str, source: str) -> list[dict]:
    """조문 트리를 food-code-analyzer 지식베이스 entry 스키마로 변환한다.

    스키마: {"category", "term", "type", "definition", "standard"}
    조 제목을 term 으로, 조문 내용을 definition 으로 쓴다.
    """
    entries = []
    for a in articles:
        term = a.get("제목")
        body = a.get("내용", "").strip()
        if not term and not body:
            continue
        num = f"제{a['번호']}조" if a.get("번호") else ""
        if a.get("가지"):
            num += f"의{a['가지']}"
        parts = [body] if body else []
        for p in a.get("항", []):
            if p.get("내용"):
                parts.append(f"{p.get('번호') or ''} {p['내용']}".strip())
            for h in p.get("호", []):
                if h.get("내용"):
                    parts.append(f"{h.get('번호')}. {h['내용']}")
        definition = " ".join(parts).strip()
        if not definition:
            continue
        entries.append(
            {
                "category": category,
                "term": term or num or "(제목 없음)",
                "type": "법령조문",
                "definition": definition[:2000],
                "standard": num or None,
                "source": source,
            }
        )
    return entries


def _kb_identity(e: dict) -> tuple:
    """지식베이스 entry 의 중복 판정 키.

    term+category 만 쓰면 같은 제목의 서로 다른 조문이 하나로 뭉개진다.
    한국 법령은 "벌칙", "정의", "위원의 신분보장" 처럼 여러 조문이 같은
    제목을 공유하는 일이 흔하다 — 실제로 「식품위생법」에는 "벌칙"이라는
    제목의 조문이 제93~98조까지 6개 있는데, term+category 만으로 중복
    판정하면 5개가 조용히 덮어써져 사라진다(실제로 겪은 데이터 손실 버그).

    조문에서 뽑은 entry 는 `standard` 에 조문번호("제73조")가 들어있으므로
    그것까지 키에 포함해 서로 다른 조문임을 구분한다. 수기로 만든
    용어집처럼 `standard` 가 없는 entry 는 기존대로 term+category 로만
    구분한다(그 경우 용어 자체가 자연스러운 고유키이기 때문).
    """
    standard = e.get("standard")
    return (e.get("term"), e.get("category"), standard) if standard else (e.get("term"), e.get("category"))


def merge_kb(existing: dict, new_entries: list[dict]) -> tuple[dict, int, int]:
    """지식베이스 JSON 에 entry 를 병합한다. (결과, 추가수, 갱신수) 반환.

    조문번호(standard)가 있으면 term+category+standard 로, 없으면
    term+category 로 중복을 판정해 같으면 갱신, 없으면 추가한다.
    """
    data = dict(existing) if existing else {}
    entries = list(data.get("entries", []))
    index = {_kb_identity(e): i for i, e in enumerate(entries)}
    added = updated = 0
    for e in new_entries:
        k = _kb_identity(e)
        if k in index:
            entries[index[k]] = e
            updated += 1
        else:
            index[k] = len(entries)
            entries.append(e)
            added += 1
    data["entries"] = entries
    return data, added, updated
